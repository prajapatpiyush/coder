document.addEventListener('DOMContentLoaded', () => {
    // Add interactivity to "Add to Cart" button
    const addToCartButton = document.querySelector('.btn');
    if (addToCartButton) {
        addToCartButton.addEventListener('click', () => {
            alert('Item added to cart!');
        });
    }

    // Change cursor size on hover over apple images
    const appleImages = document.querySelectorAll('.apples img');
    appleImages.forEach(img => {
        img.addEventListener('mouseover', () => {
            img.style.transform = "scale(1.2)"; // Enlarge apple on hover
        });
        img.addEventListener('mouseout', () => {
            img.style.transform = "scale(1)"; // Reset size when hover ends
        });
    });

    // Custom Cursor Positioning (follow mouse movement)
    const cursor = document.querySelector('.cursor');
    if (cursor) {
        document.addEventListener('mousemove', (event) => {
            const x = event.clientX;
            const y = event.clientY;
            cursor.style.left = `${x}px`;
            cursor.style.top = `${y}px`;
        });
    }

    // Handle product selection and alert
    const buyButtons = document.querySelectorAll('.buy-btn');
    buyButtons.forEach(button => {
        button.addEventListener('click', () => {
            const productName = button.closest('.product').dataset.product;
            alert(`You selected: ${productName}`);
        });
    });

    // Show discount popup when "Buy Now" button is clicked
    const buyNowButton = document.querySelector('.buy-now-btn');
    const discountPopup = document.querySelector('.discount-popup');
    const closePopupButton = document.querySelector('.close-popup-btn');

    if (buyNowButton && discountPopup && closePopupButton) {
        buyNowButton.addEventListener('click', () => {
            discountPopup.style.display = 'flex';
        });

        closePopupButton.addEventListener('click', () => {
            discountPopup.style.display = 'none';
        });

        // Close popup if clicked outside the popup content
        discountPopup.addEventListener('click', (e) => {
            if (e.target === discountPopup) {
                discountPopup.style.display = 'none';
            }
        });
    }

    // Start clock function
    function startClock() {
        setInterval(() => {
            const now = new Date();
            let hours = now.getHours();
            let minutes = now.getMinutes();
            let seconds = now.getSeconds();
            const ampm = hours >= 12 ? 'PM' : 'AM';

            hours = hours % 12 || 12;  // Convert hours to 12-hour format
            hours = hours < 10 ? '0' + hours : hours;
            minutes = minutes < 10 ? '0' + minutes : minutes;
            seconds = seconds < 10 ? '0' + seconds : seconds;

            // Update HTML content
            document.getElementById('hours').textContent = hours;
            document.getElementById('minutes').textContent = minutes;
            document.getElementById('seconds').textContent = seconds;
            document.getElementById('ampm').textContent = ampm;

            // Update the circles based on current time
            const hourProgress = (hours / 12) * 440;
            const minuteProgress = (minutes / 60) * 440;
            const secondProgress = (seconds / 60) * 440;

            document.getElementById('hh').style.strokeDashoffset = 440 - hourProgress;
            document.getElementById('mm').style.strokeDashoffset = 440 - minuteProgress;
            document.getElementById('ss').style.strokeDashoffset = 440 - secondProgress;
        }, 1000);
    }

    // Start the clock when the page loads
    startClock();

    // JavaScript to trigger animation on scroll
    const footerContent = document.querySelector('.footer-content');
    const footerBottom = document.querySelector('.footer-bottom');

    if (footerContent && footerBottom) {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.5
        };

        // Intersection Observer to trigger the animation when footer comes into view
        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    footerContent.style.animation = 'fadeIn 1s forwards';
                    footerBottom.style.animation = 'fadeIn 1.5s forwards';
                }
            });
        }, observerOptions);

        // Start observing the footer content
        observer.observe(footerContent);
    }
});

